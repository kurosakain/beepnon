# ![logo](LINE-sm.png) LINE Python

*LINE Messaging's private API*

----

## Installation for Termux

```sh
$ apt update
$ apt upgrade
$ apt install python
$ apt install git
$ git clone https://github.com/arifistifik/sb
$ cd sb
$ python sb.py
```

## Installation for VPS

```sh
$ git clone https://github.com/arifistifik/sb
$ cd sb
$ python3 sb.py
```

## Attention

for the first time running python helloworld.py will be an error

## LINE
[DRAGON PLAY KILL]

## Thanks For Allmastah
